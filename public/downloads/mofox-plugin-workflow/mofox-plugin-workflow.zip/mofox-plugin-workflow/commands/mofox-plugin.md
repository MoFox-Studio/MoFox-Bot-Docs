---
description: 按完整工作流开发 Neo-MoFox 插件，从需求澄清到契约测试、Review 和交付
argument-hint: "[插件需求]"
disable-model-invocation: true
---

加载 `mofox-plugin-workflow` Skill，并以它为准执行 Phase 0–6。适用的参考资料和脚本均从该 Skill 所在目录读取。如果还没有给出插件需求，先问用户想做什么。

- 给出设计方案并得到用户确认后，才开始写插件代码。
- 按 Phase 4 编写测试，包含 `references/test-patterns.md` 中的组件构造/执行契约测试。
- 按 Phase 5 完成静态检查、框架真实加载/卸载、测试、人工一致性检查。新插件报告之前必须执行 Phase 5.5，按 `references/review-rules.md` 优先检查框架契约。
- 在 Phase 6 报告真实验证结果、契约测试、Review 和未覆盖范围。按 Skill 规则分别确认版本递增、提交、构建、推送等动作，不自动执行。

用户提供的插件需求：

$ARGUMENTS
