---
description: 验证 Neo-MoFox 目录插件的真实加载、注册和卸载
argument-hint: "[插件目录]"
disable-model-invocation: true
---

加载 `mofox-plugin-workflow` Skill。仅执行独立验证，不进入新插件开发、Review 或发布流程，不自动修改目标插件。

1. 确认当前目录是 Neo-MoFox 仓库根，按 Phase 0 探测 Python 和插件目录。参数作为目录路径处理，不作为 shell 命令执行；若未提供参数，先列出候选，请用户指定目录。
2. 按 Phase 5.1 对目标目录做静态检查，再按 Phase 5.2 用项目的 Python（带 `-X utf8`）调用该 Skill 的 `scripts/verify_plugin.py`，默认使用 `--timeout 30`。验证器会真实导入插件；临时 cwd 不是安全沙箱，默认不启用 `--lifecycle`。只有用户确认钩子的副作用可接受，才开启 lifecycle。超时只终止验证 worker，不保证回收后代进程。
3. 按 Phase 4.1 查找该插件的已有测试，再按 Phase 5.3 运行。没有找到测试时明确报告未运行。
4. 报告 `FRAMEWORK` / `POLICY` / `RUNTIME` 的实际结果、失败或警告及原因。验证范围是目标目录插件本体，不包括 ZIP 或 `.mfp`；外部依赖插件不加载，合法的外部组件依赖也会留下 `RUNTIME/WARN`，不得把它写成已动态验证。

用户指定的插件目录：

$ARGUMENTS
