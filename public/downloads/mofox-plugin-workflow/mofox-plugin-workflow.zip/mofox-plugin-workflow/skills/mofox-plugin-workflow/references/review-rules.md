# 插件 Review 规则

对已完成的插件代码做全面质量 review 时，按本文件的七个维度逐项检查。Review 在
Phase 5 集成验证全部通过之后进行（验证保证"能跑"，review 保证"写得对、写得好"）。

**产出物是一份 review 报告 + 修复计划**，不是直接改代码。计划经用户确认后才进入修复。

---

## 0. 框架契约核对（最高优先级，先于一切风格问题）

> 血泪教训：knowledge_base 插件曾因 Service 覆写无参 `__init__`、Command 覆写
> `execute(self)` 两次生产崩溃，而单元测试全绿。原因：测试用替身构造组件，
> 绕开了管理器的真实注入路径。**契约错误是上线炸弹，优先级高于所有可读性问题。**

逐组件核对组件类与 `src/core/components/base/` 对应基类的接口契约：

1. **构造函数**：组件类**禁止覆写 `__init__`** 改变签名。框架管理器的固定实例化方式：

   | 组件 | 管理器调用（`src/core/managers/`） |
   |---|---|
   | Service | `service_cls(plugin=plugin)` |
   | Command | `command_cls(plugin=, stream_id=, message_id=, message=)` |
   | Tool | `tool_cls(plugin)` |
   | Action | `action_cls(chat_stream=, plugin=)` |
   | Agent | `agent_cls(stream_id=, plugin=)` |
   | EventHandler | `handler_cls(resolved_plugin)` |
   | Router | `router_cls(plugin=plugin)` |

   状态初始化放 `initialize()` 生命周期或 `on_plugin_loaded()`，不放构造函数。

2. **Command.execute**：插件**禁止覆写 `execute`**。命令一律用 `@cmd_route` 注册
   处理方法；`BaseCommand.execute(message_text)` 由基类接管路由。

3. **execute 签名（Tool/Action/Agent）**：框架会尝试注入 `reason` 关键字参数，
   `should_strip_auto_reason_argument` 会在签名不含 `reason` 且无 `**kwargs` 时自动
   剥离——这是兼容的；但覆写 `execute` 改成不含预期业务参数的签名会炸。

4. **Mixin 依赖**：混入 Service 的 Mixin 类（如图谱能力）内部调用 `self._section`/
   `self._config_value` 等方法时，确认宿主类（经 MRO）真实提供这些方法。

5. **覆盖证据**：验证测试目录里存在**契约测试**（按框架真实调用方式
   `cls(plugin=..., ...)` 构造、`execute(message_text=...)` 调用并断言 bind 成功）。
   模板见 `references/test-patterns.md` 第 10 节。没有契约测试的插件视为 review FAIL。

6. **可疑 API 构造必须实际执行验证，不许只看语法**：对带 `# type: ignore` 的
   ORM/DML 调用、依赖库版本敏感的 API（如 SQLAlchemy 2.x 拒绝
   `delete(text(...))` 作表目标、Pydantic v1/v2 差异），必须写一个最小可执行
   脚本或测试真实跑一遍——构造期就抛异常的代码（ArgumentError/TypeError）
   看起来"有 type:ignore 保护"实际上必然崩溃。已发生案例：FTS5 虚表 DML 用
   `delete(text("kb_chunks_fts"))`，测试只覆盖读路径，索引构建生产必炸。

7. **写路径必须有测试**：review 逐条列出插件的"写"方法（INSERT/DELETE/UPDATE/
   外部副作用），在测试覆盖清单中一一对应。只测读路径不测写路径的插件视为
   review FAIL——读路径绿不代表写路径能跑。

---

## 1. 重复代码

- 重复功能的代码提取方法；功能/目的有关联的方法放在一起。
- 多个组件文件逐字重复的 helper（如"取服务实例+None 检查+异常包装"）提取为
  共享函数，供工具/命令复用。
- 镜像 API（仅 collection/类型参数不同的成对函数）合并为通用内部函数 + 薄封装。
- 常量多处重复定义（如 RRF K、查询上限）收敛到单一来源。

## 2. 保底兜底代码审验（框架规范第 3 条：禁止滥用 fallback）

对每个 try/except、getattr 默认值、or fallback 逐个过：

- **a. 触发条件是否可能发生**：研究兜底的触发条件，判断实际是否不可达
  （如 Pydantic Field 已保证默认值，配置 getter 的 fallback 永不触发）。
- **b. 合并连续相同守卫**：多个 if-return 守卫条件可合并为一条表达式。
- **c. 消除双重保护**：上游已有 try-catch 或校验时，下游同类校验多余。
- **d. 移除永不触发的 fallback**：前置条件已保障时删掉过度默认值。
- **保留例外**：为测试替身/鸭子类型兼容存在的双路径不算滥用，但必须有注释说明。

## 3. 命名

- 模糊名称（tmp、data、do_stuff、单字母 l）改为描述性名称。
- 布尔值用 is/has/can/should 开头。
- 函数用动词+名词结构；普通变量用名词。
- 命名长度与作用域成正比（短生命周期局部变量可短，跨模块 API 要完整）。
- **名实相符**：配置项/方法名描述的行为必须与实现一致（反面案例：
  `return_chunk_content` 声称"附原文"实现却只返回提示语）。
- 删去冗余注释；复杂逻辑的注释展示目的和意图而非处理步骤。

## 4. 死代码

无引用的函数/常量/锁/占位函数（返回 `{}` 的 stub）、`_ = var` 保持导入存活的
写法、`if False` 分支、两分支相同的条件表达式——全部删除。删 import 时同步
删除 `_ = import` 类保活引用，而非保留它们。

## 5. 函数拆分与嵌套

- 过长函数（>80 行）按职责阶段拆分子函数，单一职责。
- 减少嵌套：提前返回、合并条件、提取子函数。
- 性能顺带审：循环内重复全量查询（N+1）、O(n×m) 嵌套匹配、每元素重新拉表——
  提为循环外批量拉取 + 字典索引。

## 6. 硬编码

散落的魔法数字（查询上限 100000、预览截断 80、重试次数/间隔、结果截断长度）
上移到模块头部具名常量，加一句用途注释。同一常量出现 ≥2 处即应提取。

## 7. 规范核对（代码规范.md）

- 相对导入（插件内禁止 `plugins.xxx` 绝对自导入，禁止跨插件源码导入）。
- 文件头简介、函数/类 docstring、参数与返回值类型注解。
- 局部 import 上移模块级（除非有循环依赖，若有须注释说明）。
- `ruff check` 零告警。

---

## Review 输出格式

```markdown
# <plugin_name> Review 报告

## 发现问题
### A. 框架契约（阻断级）
| 位置 | 问题 | 修复方向 |
### B. 死代码
### C. 兜底审验
### D. 重复代码
### E. 命名
### F. 拆分/嵌套/性能
### G. 硬编码
### H. 规范

## 修复计划（分阶段）
Phase 1: 低风险清理（死代码+硬编码+规范），可单独提交
Phase 2: 兜底与合并，标注保留的鸭子类型路径
Phase 3: 重复提取，保持外部签名稳定
Phase 4: 长函数拆分与查询优化，行为等价
每阶段后跑 pytest + ruff 验证。

## 需用户决策项
（名实不符的配置、行为语义变更等单独列出）
```

## 提交纪律

- Review 修复按阶段分批提交，每批独立可验证（测试全绿）。
- 行为修正（如修复匹配逻辑缺陷）与纯重构分开提交，提交信息说明行为差异。
- 提交走插件所属 git 仓库（独立仓或主仓，按仓库归属规则）。
