"""Targeted tests for the Neo-MoFox plugin verifier."""

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path
from types import ModuleType
from typing import Callable

import pytest

VERIFIER = (
    Path(__file__).parents[1]
    / "skills"
    / "mofox-plugin-workflow"
    / "scripts"
    / "verify_plugin.py"
)
PROJECT_ROOT = Path(
    os.environ.get("NEO_MOFOX_ROOT", "X:/WorkSpace/py/neo-mofox/Neo-MoFox")
)
PYTHON = PROJECT_ROOT / ".venv" / "Scripts" / "python.exe"
if not PYTHON.is_file():
    PYTHON = Path(sys.executable)


def load_verifier_module() -> ModuleType:
    """Load the verifier as a module for focused unit tests."""
    spec = importlib.util.spec_from_file_location("mofox_work_verify_plugin", VERIFIER)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture()
def plugin_factory(tmp_path: Path) -> Callable[..., Path]:
    """Create a minimal directory plugin and optional component declarations."""

    def create(
        *,
        name: str = "verify_fixture",
        component_code: str = "",
        component_names: str = "[]",
        configs: str = "[]",
        minimum: str | None = "0.0.0",
        include_minimum: bool = True,
        dependencies: dict[str, list[str]] | None = None,
        include: list[dict[str, object]] | None = None,
        python_dependencies: list[str] | None = None,
        dependencies_required: bool = True,
        lifecycle_code: str = "",
        extra_registration: bool = False,
    ) -> Path:
        plugin_dir = tmp_path / "plugins" / name
        plugin_dir.mkdir(parents=True)
        manifest = {
            "name": name,
            "version": "1.0.0",
            "description": "verifier fixture",
            "author": "tests",
            "dependencies": dependencies or {"plugins": [], "components": []},
            "entry_point": "plugin.py",
            "python_dependencies": python_dependencies or [],
            "dependencies_required": dependencies_required,
            "include": include or [],
        }
        if include_minimum:
            manifest["min_core_version"] = minimum
        (plugin_dir / "manifest.json").write_text(
            json.dumps(manifest), encoding="utf-8"
        )
        (plugin_dir / "__init__.py").write_text("", encoding="utf-8")
        extra_registration_code = ""
        if extra_registration:
            extra_registration_code = f'''
from src.core.components.registry import get_global_registry

class ExtraRegistryService:
    """Unexpected registry fixture."""

get_global_registry().register(
    ExtraRegistryService,
    {f"{name}:service:extra"!r},
)
'''
        source = f'''"""Generated verifier fixture."""
from src.core.components.base.plugin import BasePlugin
from src.core.components.loader import register_plugin
{component_code}
{extra_registration_code}

@register_plugin
class FixturePlugin(BasePlugin):
    """Minimal fixture plugin."""
    plugin_name = {name!r}
    plugin_description = "fixture"
    plugin_version = "1.0.0"
    configs = {configs}

    def get_components(self):
        """Return fixture components."""
        return {component_names}

{lifecycle_code}
'''
        (plugin_dir / "plugin.py").write_text(source, encoding="utf-8")
        return plugin_dir

    return create


def run_verify(
    plugin_dir: Path,
    *extra_args: str,
    timeout: float = 45,
) -> subprocess.CompletedProcess[str]:
    """Run verifier in JSON mode."""
    command = [
        str(PYTHON),
        "-X",
        "utf8",
        str(VERIFIER),
        str(plugin_dir),
        "--project-root",
        str(PROJECT_ROOT),
        "--json",
        *extra_args,
    ]
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
        timeout=timeout,
    )


def results_by_id(
    completed: subprocess.CompletedProcess[str],
) -> tuple[dict[str, object], dict[str, dict[str, object]]]:
    """Parse report and index checks by ID."""
    report = json.loads(completed.stdout)
    return report, {item["check_id"]: item for item in report["results"]}


def action_code(associated_types: str, dependencies: str = "[]") -> str:
    """Build one Action component declaration."""
    return f'''
from src.core.components.base.action import BaseAction

class FixtureAction(BaseAction):
    """Fixture action."""
    name = "act"
    description = "fixture"
    associated_types = {associated_types}
    dependencies = {dependencies}

    async def execute(self):
        """Execute fixture action."""
        return True, "ok"
'''


def test_valid_minimal_load_unload_and_json(
    plugin_factory: Callable[..., Path],
) -> None:
    """A minimal plugin uses real manager load/unload and emits clean JSON."""
    completed = run_verify(plugin_factory())
    report, checks = results_by_id(completed)
    assert completed.returncode == 0, completed.stdout
    assert report["plugin_name"] == "verify_fixture"
    assert checks["D1"]["status"] == "PASS"
    assert checks["D13"]["status"] == "PASS"
    assert all(
        item["category"] in {"FRAMEWORK", "POLICY", "RUNTIME"}
        for item in report["results"]
    )


@pytest.mark.parametrize("kind", ["action", "agent"])
def test_empty_associated_types_fails(
    plugin_factory: Callable[..., Path], kind: str
) -> None:
    """Action and Agent call their real associated_types validators."""
    if kind == "action":
        code = action_code("[]")
        names = "[FixtureAction]"
    else:
        code = '''
from src.core.components.base.agent import BaseAgent
class FixtureAgent(BaseAgent):
    """Fixture agent."""
    name = "agent"
    description = "fixture"
    associated_types = []
    async def execute(self):
        """Execute fixture agent."""
        return True, "ok"
'''
        names = "[FixtureAgent]"
    completed = run_verify(plugin_factory(component_code=code, component_names=names))
    _, checks = results_by_id(completed)
    assert completed.returncode == 1
    assert checks["D1"]["status"] == "FAIL"
    assert checks["D5"]["status"] == "FAIL"


@pytest.mark.parametrize("kind", ["action", "agent"])
def test_valid_associated_types_passes(
    plugin_factory: Callable[..., Path], kind: str
) -> None:
    """Action and Agent accept a non-empty associated_types declaration."""
    if kind == "action":
        code = action_code("['text']")
        names = "[FixtureAction]"
    else:
        code = '''
from src.core.components.base.agent import BaseAgent
class FixtureAgent(BaseAgent):
    """Fixture agent."""
    name = "agent"
    description = "fixture"
    associated_types = ["text"]
    async def execute(self):
        """Execute fixture agent."""
        return True, "ok"
'''
        names = "[FixtureAgent]"
    completed = run_verify(plugin_factory(component_code=code, component_names=names))
    _, checks = results_by_id(completed)
    assert completed.returncode == 0, completed.stdout
    assert checks["D5"]["status"] == "PASS"


def test_invalid_dependency_signature(plugin_factory: Callable[..., Path]) -> None:
    """Dependency syntax is validated through parse_signature."""
    completed = run_verify(
        plugin_factory(
            component_code=action_code("['text']", "['not-a-signature']"),
            component_names="[FixtureAction]",
        )
    )
    _, checks = results_by_id(completed)
    assert completed.returncode == 1
    assert checks["D6"]["status"] == "FAIL"


def test_missing_internal_dependency(plugin_factory: Callable[..., Path]) -> None:
    """A valid but absent internal dependency fails."""
    completed = run_verify(
        plugin_factory(
            component_code=action_code("['text']", "['verify_fixture:tool:missing']"),
            component_names="[FixtureAction]",
        )
    )
    _, checks = results_by_id(completed)
    assert completed.returncode == 1
    assert checks["D7"]["status"] == "FAIL"


def test_incompatible_version(plugin_factory: Callable[..., Path]) -> None:
    """The framework's real version checker rejects an impossible minimum."""
    completed = run_verify(plugin_factory(minimum="9999.0.0"))
    _, checks = results_by_id(completed)
    assert completed.returncode == 1
    assert checks["S9"]["status"] == "FAIL"


def test_config_stays_out_of_project(plugin_factory: Callable[..., Path]) -> None:
    """BaseConfig writes only beneath the worker temporary cwd."""
    name = "verify_config_fixture"
    real_config = PROJECT_ROOT / "config" / "plugins" / name
    code = '''
from src.core.components.base.config import BaseConfig, Field, SectionBase, config_section
class FixtureConfig(BaseConfig):
    """Fixture config."""
    name = "config"
    @config_section("general")
    class General(SectionBase):
        """Fixture section."""
        enabled: bool = Field(default=True, description="enabled")
    general: General = Field(default_factory=General)
'''
    completed = run_verify(
        plugin_factory(name=name, component_code=code, configs="[FixtureConfig]")
    )
    assert completed.returncode == 0, completed.stdout
    assert not real_config.exists()


def test_python_dependency_required_missing_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Missing required Python dependencies are hard failures."""
    verifier = load_verifier_module()
    report = verifier.Report("fixture")

    def missing(_name: str) -> str:
        raise importlib.metadata.PackageNotFoundError

    monkeypatch.setattr(verifier.importlib.metadata, "version", missing)
    verifier.check_python_dependencies(report, ["missing-package>=1"], required=True)
    assert report.results[-1].status == verifier.FAIL


def test_python_dependency_optional_mismatch_warns(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Missing or incompatible optional dependencies only warn."""
    verifier = load_verifier_module()
    report = verifier.Report("fixture")
    monkeypatch.setattr(verifier.importlib.metadata, "version", lambda _name: "1.0")
    verifier.check_python_dependencies(report, ["example-package>=2"], required=False)
    assert report.results[-1].status == verifier.WARN


def test_python_dependency_inapplicable_marker_skips(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Requirements excluded by their marker are reported as skipped."""
    verifier = load_verifier_module()
    report = verifier.Report("fixture")

    def unexpected(_name: str) -> str:
        pytest.fail("version lookup must not run for an inapplicable marker")

    monkeypatch.setattr(verifier.importlib.metadata, "version", unexpected)
    verifier.check_python_dependencies(
        report,
        ["example-package; python_version < '2'"],
        required=True,
    )
    result = report.results[-1]
    assert result.status == verifier.SKIP
    assert "marker 不适用于当前环境" in result.detail


def test_dependency_cycle_fails_planning(plugin_factory: Callable[..., Path]) -> None:
    """The real loader rejects a circular plugin dependency graph."""
    plugin = plugin_factory(
        name="cycle_a",
        dependencies={"plugins": ["cycle_b"], "components": []},
    )
    plugin_factory(
        name="cycle_b",
        dependencies={"plugins": ["cycle_a"], "components": []},
    )
    completed = run_verify(plugin)
    _, checks = results_by_id(completed)
    assert completed.returncode == 1
    assert checks["S10"]["status"] == "FAIL"
    assert "循环依赖" in checks["S10"]["detail"]


def test_strict_warning_returns_two(plugin_factory: Callable[..., Path]) -> None:
    """Strict mode maps policy warnings to exit code two."""
    plugin = plugin_factory(
        include=[
            {
                "component_type": "service",
                "component_name": "declared_only",
                "dependencies": [],
                "enabled": True,
            }
        ]
    )
    completed = run_verify(plugin, "--strict")
    assert completed.returncode == 2


def test_declared_external_dependency_warns_and_strict_returns_two(
    plugin_factory: Callable[..., Path],
) -> None:
    """Declared external components are not loaded and remain runtime warnings."""
    plugin_factory(name="other_plugin")
    completed = run_verify(
        plugin_factory(
            component_code=action_code(
                "['text']", "['other_plugin:service:remote']"
            ),
            component_names="[FixtureAction]",
            dependencies={
                "plugins": ["other_plugin"],
                "components": ["other_plugin:service:remote"],
            },
        ),
        "--strict",
    )
    _, checks = results_by_id(completed)
    assert completed.returncode == 2
    assert checks["D8"]["status"] == "PASS"
    assert checks["D8b"]["status"] == "WARN"
    assert "不会加载依赖插件" in checks["D8b"]["detail"]


@pytest.mark.parametrize("minimum", [None, "", "   "])
def test_missing_null_or_blank_minimum_warns(
    plugin_factory: Callable[..., Path], minimum: str | None
) -> None:
    """Only a non-blank string min_core_version passes policy S3."""
    completed = run_verify(plugin_factory(minimum=minimum))
    _, checks = results_by_id(completed)
    assert completed.returncode in {0, 1}
    assert checks["S3"]["status"] == "WARN"


def test_missing_minimum_key_warns(plugin_factory: Callable[..., Path]) -> None:
    """A missing min_core_version key warns under policy S3."""
    completed = run_verify(plugin_factory(include_minimum=False))
    _, checks = results_by_id(completed)
    assert completed.returncode == 0
    assert checks["S3"]["status"] == "WARN"


def test_extra_registry_registration_fails_d10(
    plugin_factory: Callable[..., Path],
) -> None:
    """Module-level registry additions outside get_components fail exact D10."""
    completed = run_verify(plugin_factory(extra_registration=True))
    _, checks = results_by_id(completed)
    assert completed.returncode == 1
    assert checks["D10"]["status"] == "FAIL"
    assert "extra=['verify_fixture:service:extra']" in checks["D10"]["detail"]


def test_lifecycle_uses_formal_manager_context(
    plugin_factory: Callable[..., Path],
) -> None:
    """Lifecycle hooks execute after manager bookkeeping and before its removal."""
    lifecycle_code = """
    async def on_plugin_loaded(self):
        from src.core.managers.plugin_manager import get_plugin_manager
        manager = get_plugin_manager()
        assert manager.get_plugin(self.plugin_name) is self
        assert manager.get_plugin_path(self.plugin_name)

    async def on_plugin_unloaded(self):
        from src.core.managers.plugin_manager import get_plugin_manager
        manager = get_plugin_manager()
        assert manager.get_plugin(self.plugin_name) is self
        assert manager.get_plugin_path(self.plugin_name)
"""
    completed = run_verify(
        plugin_factory(lifecycle_code=lifecycle_code),
        "--lifecycle",
    )
    _, checks = results_by_id(completed)
    assert completed.returncode == 0, completed.stdout
    assert checks["L1"]["status"] == "PASS"
    assert checks["L2"]["status"] == "PASS"


def test_default_mode_replaces_lifecycle_with_noop(
    plugin_factory: Callable[..., Path],
) -> None:
    """Lifecycle hooks are not executed unless explicitly requested."""
    lifecycle_code = """
    async def on_plugin_loaded(self):
        raise RuntimeError("load hook must be disabled")

    async def on_plugin_unloaded(self):
        raise RuntimeError("unload hook must be disabled")
"""
    completed = run_verify(plugin_factory(lifecycle_code=lifecycle_code))
    _, checks = results_by_id(completed)
    assert completed.returncode == 0, completed.stdout
    assert "L1" not in checks
    assert "L2" not in checks


def test_timeout_branch_reports_script_error(
    plugin_factory: Callable[..., Path],
) -> None:
    """The parent terminates a worker that exceeds --timeout."""
    lifecycle_code = """
    async def on_plugin_loaded(self):
        import asyncio
        await asyncio.sleep(1)
"""
    completed = run_verify(
        plugin_factory(lifecycle_code=lifecycle_code),
        "--lifecycle",
        "--timeout",
        "0.05",
    )
    _, checks = results_by_id(completed)
    assert completed.returncode == 3
    assert checks["X0"]["title"] == "验证子进程超时"


def test_reset_rebinds_event_manager_to_new_bus() -> None:
    """Reset order discards the old manager before creating a fresh event bus."""
    verifier = load_verifier_module()
    if str(PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(PROJECT_ROOT))
    import src.core.managers.event_manager as event_module
    import src.kernel.event as kernel_event

    verifier.reset_framework_singletons()
    first_manager = event_module.get_event_manager()
    first_bus = first_manager._event_bus
    assert first_bus is kernel_event.get_event_bus()

    verifier.reset_framework_singletons()
    second_manager = event_module.get_event_manager()
    second_bus = second_manager._event_bus
    assert second_manager is not first_manager
    assert second_bus is not first_bus
    assert second_bus is kernel_event.get_event_bus()
